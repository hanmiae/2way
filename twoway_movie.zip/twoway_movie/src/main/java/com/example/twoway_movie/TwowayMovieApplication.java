package com.example.twoway_movie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwowayMovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwowayMovieApplication.class, args);
	}

}
