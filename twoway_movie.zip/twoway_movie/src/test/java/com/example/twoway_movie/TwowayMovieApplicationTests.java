package com.example.twoway_movie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwowayMovieApplicationTests {

	@Test
	void contextLoads() {
	}

}
